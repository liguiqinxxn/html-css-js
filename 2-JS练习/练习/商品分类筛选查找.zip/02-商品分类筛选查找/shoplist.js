var shopsList = [
	{
		imgUrl:'./img/img1.jpg',
		size: '4.0-4.5英寸',
		system: 'ios',
		www:'联通3G',
		name:'苹果',
		volume:100000,
		price: 5000
	},
	{
		imgUrl:'./img/img1.jpg',
		size: '4.0-4.5英寸',
		system: 'ios',
		www:'双卡单4G',
		name:'苹果',
		volume:100,
		price: 50000
	},
	{
		imgUrl:'./img/img2.jpg',
		size: '4.6-4.9英寸',
		system: 'ios',
		www:'双卡单4G',
		name:'苹果',
		volume:30,
		price: 50080
	},
	{
		imgUrl:'./img/img3.jpg',
		size: '4.6-4.9英寸',
		system: 'android',
		www:'联通3G',
		name:'小米',
		volume:1020,
		price: 50400
	},
	{
		imgUrl:'./img/img4.jpg',
		size: '4.0-4.5英寸',
		system: 'android',
		www:'双卡单4G',
		name:'小米',
		volume:10400,
		price: 54000
	},
	{
		imgUrl:'./img/img5.jpg',
		size: '4.6-4.9英寸',
		system: 'android',
		www:'双卡单4G',
		name:'小米',
		volume:1004,
		price: 500040
	}
]